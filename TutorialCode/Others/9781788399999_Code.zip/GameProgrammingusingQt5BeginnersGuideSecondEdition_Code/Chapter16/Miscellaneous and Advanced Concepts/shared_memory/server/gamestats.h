#ifndef GAMESTATS_H
#define GAMESTATS_H

#include <QtGlobal>

struct GameStats {
  quint32 playerCount = 0;
  quint32 uptime = 0;
};

#endif // GAMESTATS_H
