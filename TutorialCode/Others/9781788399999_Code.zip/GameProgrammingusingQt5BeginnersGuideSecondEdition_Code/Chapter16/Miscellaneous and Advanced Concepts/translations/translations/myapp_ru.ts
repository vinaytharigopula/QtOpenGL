<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>Widget</name>
    <message>
        <location filename="../widget.ui" line="14"/>
        <source>Widget</source>
        <translation>Виджет</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="20"/>
        <source>Left</source>
        <translation>Левое</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="27"/>
        <source>Right</source>
        <translation>Правое</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="23"/>
        <source>You clicked left!</source>
        <translation>Вы кликнули левое!</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="28"/>
        <source>You clicked right!</source>
        <translation>Вы кликнули правое!</translation>
    </message>
</context>
</TS>
