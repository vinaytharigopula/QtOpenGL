<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Widget</name>
    <message>
        <location filename="../widget.ui" line="14"/>
        <source>Widget</source>
        <translation>Widget</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="20"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="27"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="23"/>
        <source>You clicked left!</source>
        <translation>Du hast nach links geklickt!</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="28"/>
        <source>You clicked right!</source>
        <translation>Du hast nach rechts geklickt!</translation>
    </message>
</context>
</TS>
