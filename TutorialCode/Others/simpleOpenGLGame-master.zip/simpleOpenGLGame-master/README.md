# simpleOpenGLGame
simple opengl game, will help you to be more familiar with opengl in real world
