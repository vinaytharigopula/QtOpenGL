A simple example to display triangle and points with the new QOpenglWidget in Qt 5.6.
