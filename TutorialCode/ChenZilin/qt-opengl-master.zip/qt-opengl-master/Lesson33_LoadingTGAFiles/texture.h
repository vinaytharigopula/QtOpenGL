#ifndef TEXTURE_H
#define TEXTURE_H

#include <gl\gl.h> // Header for OpenGL32 library




#endif // TEXTURE_H
