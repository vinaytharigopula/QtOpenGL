﻿#include <QApplication>

#include <GL/glu.h>
#include <myglwidget.h>

//创建一个OpenGL窗口:
//在这个教程里,我将教你使用Qt创建OpenGL程序.
//它将显示一个空的OpenGL窗口,可以在窗口和全屏模式下切换,按ESC退出.它是我们以后应用程序的框架.

MyGLWidget::MyGLWidget(QWidget *parent) :
	QGLWidget(parent), mFullScreen(false)
{
	showNormal();
}

MyGLWidget::~MyGLWidget()
{
}

//下面的代码的作用是重新设置OpenGL场景的大小，而不管窗口的大小是否已经改变(假定您没有使用全屏模式)。
//甚至您无法改变窗口的大小时(例如您在全屏模式下)，它至少仍将运行一次--在程序开始时设置我们的透视图。
//OpenGL场景的尺寸将被设置成它显示时所在窗口的大小。
void MyGLWidget::resizeGL(int width, int height)
{
	if (height == 0) { // 防止被零除
		height = 1; // 将高设为1
	}

	glViewport(0, 0, width, height); //重置当前的视口
	//下面几行为透视图设置屏幕。意味着越远的东西看起来越小。这么做创建了一个现实外观的场景。
	//此处透视按照基于窗口宽度和高度的45度视角来计算。0.1f，100.0f是我们在场景中所能绘制深度的起点和终点。
	//glMatrixMode(GL_PROJECTION)指明接下来的两行代码将影响projection matrix(投影矩阵)。
	//投影矩阵负责为我们的场景增加透视。 glLoadIdentity()近似于重置。它将所选的矩阵状态恢复成其原始状态。
	//调用glLoadIdentity()之后我们为场景设置透视图。
	//glMatrixMode(GL_MODELVIEW)指明任何新的变换将会影响 modelview matrix(模型观察矩阵)。
	//模型观察矩阵中存放了我们的物体讯息。最后我们重置模型观察矩阵。如果您还不能理解这些术语的含义，请别着急。
	//在以后的教程里，我会向大家解释。只要知道如果您想获得一个精彩的透视场景的话，必须这么做。
	glMatrixMode(GL_PROJECTION);// 选择投影矩阵
	glLoadIdentity();// 重置投影矩阵
	//设置视口的大小
	gluPerspective(45.0f, (GLfloat)width/(GLfloat)height, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);	//选择模型观察矩阵
	glLoadIdentity(); // 重置模型观察矩阵
}

//接下的代码段中，我们将对OpenGL进行所有的设置。我们将设置清除屏幕所用的颜色，打开深度缓存，启用smooth shading(阴影平滑)，等等。
//这个例程直到OpenGL窗口创建之后才会被调用。此过程将有返回值。但我们此处的初始化没那么复杂，现在还用不着担心这个返回值。
void MyGLWidget::initializeGL()
{
	//下一行启用smooth shading(阴影平滑)。阴影平滑通过多边形精细的混合色彩，并对外部光进行平滑。
	//我将在另一个教程中更详细的解释阴影平滑。
	glShadeModel(GL_SMOOTH); // 启用阴影平滑

	//下一行设置清除屏幕时所用的颜色。如果您对色彩的工作原理不清楚的话，我快速解释一下。
	//色彩值的范围从0.0f到1.0f。0.0f代表最黑的情况，1.0f就是最亮的情况。
	//glClearColor 后的第一个参数是Red Intensity(红色分量),第二个是绿色，第三个是蓝色。
	//最大值也是1.0f，代表特定颜色分量的最亮情况。最后一个参数是Alpha值。当它用来清除屏幕的时候，我们不用关心第四个数字。
	//现在让它为0.0f。我会用另一个教程来解释这个参数。
	//通过混合三种原色(红、绿、蓝)，您可以得到不同的色彩。希望您在学校里学过这些。
	//因此，当您使用glClearColor(0.0f,0.0f,1.0f,0.0f)，您将用亮蓝色来清除屏幕。
	//如果您用 glClearColor(0.5f,0.0f,0.0f,0.0f)的话，您将使用中红色来清除屏幕。不是最亮(1.0f)，也不是最暗 (0.0f)。
	//要得到白色背景，您应该将所有的颜色设成最亮(1.0f)。要黑色背景的话，您该将所有的颜色设为最暗(0.0f)。
	glClearColor(0.0f, 0.0f, 1.0f, 0.0f); // 蓝色背景

	//接下来的三行必须做的是关于depth buffer(深度缓存)的。将深度缓存设想为屏幕后面的层。
	//深度缓存不断的对物体进入屏幕内部有多深进行跟踪。
	//我们本节的程序其实没有真正使用深度缓存，但几乎所有在屏幕上显示3D场景OpenGL程序都使用深度缓存。
	//它的排序决定那个物体先画。这样您就不会将一个圆形后面的正方形画到圆形上来。深度缓存是OpenGL十分重要的部分。
	glClearDepth(1.0f);	// 设置深度缓存
	glEnable(GL_DEPTH_TEST); // 启用深度测试
	glDepthFunc(GL_LEQUAL);	// 所作深度测试的类型

	//接着告诉OpenGL我们希望进行最好的透视修正。这会十分轻微的影响性能。但使得透视图看起来好一点。
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// 告诉系统对透视进行修正
}

//下一段包括了所有的绘图代码。任何您所想在屏幕上显示的东东都将在此段代码中出现。
//以后的每个教程中我都会在例程的此处增加新的代码。如果您对OpenGL已经有所了解的话，您可以在glLoadIdentity()调用之后，
//试着添加一些OpenGL代码来创建基本的形。
//如果您是OpenGL新手，等着我的下个教程。目前我们所作的全部就是将屏幕清除成我们前面所决定的颜色，清除深度缓存并且重置场景。
//我们仍没有绘制任何东东。
void MyGLWidget::paintGL()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	//清除屏幕和深度缓存
	glLoadIdentity();	// 重置当前的模型观察矩阵
}

void MyGLWidget::keyPressEvent(QKeyEvent *event)
{
	switch(event->key())
	{
	case Qt::Key_F2:
	{
		mFullScreen = !mFullScreen;
		if(mFullScreen) {
			showFullScreen();
		}
		else {
			showNormal();
		}
		updateGL();
		break;
	}
	case Qt::Key_Escape:
	{
		qApp->exit();
		break;
	}
	}
}
