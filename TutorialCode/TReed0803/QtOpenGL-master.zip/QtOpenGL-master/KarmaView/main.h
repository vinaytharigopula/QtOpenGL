#ifndef MAIN_H
#define MAIN_H

class QPlainTextEdit;
extern QPlainTextEdit *sg_console;

#endif // MAIN_H
