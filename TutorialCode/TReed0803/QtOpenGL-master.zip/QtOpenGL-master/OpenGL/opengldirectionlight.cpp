#include "opengldirectionlight.h"

OpenGLDirectionLight::OpenGLDirectionLight() :
  m_direction(-0.57735f, -0.57735f, -0.57735f)
{
  // Intentionally Empty
}
