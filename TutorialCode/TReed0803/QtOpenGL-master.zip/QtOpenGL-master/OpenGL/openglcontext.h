#ifndef OPENGLCONTEXT_H
#define OPENGLCONTEXT_H OpenGLContext

#include <QOpenGLContext>

class OpenGLContext : public QOpenGLContext
{
  // Intentionally Empty
};

#endif // OPENGLCONTEXT_H
