#ifndef OPENGLBINDINGS_H
#define OPENGLBINDINGS_H OpenGLBindings

#include <resources/shaders/Bindings.glsl>

#endif // OPENGLBINDINGS_H

