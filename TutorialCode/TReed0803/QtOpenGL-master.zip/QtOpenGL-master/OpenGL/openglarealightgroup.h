#ifndef OPENGLAREALIGHTGROUP_H
#define OPENGLAREALIGHTGROUP_H OpenGLAreaLightGroup

class OpenGLAreaLightGroup
{
public:
  OpenGLAreaLightGroup();
  ~OpenGLAreaLightGroup();
};

#endif // OPENGLAREALIGHTGROUP_H
