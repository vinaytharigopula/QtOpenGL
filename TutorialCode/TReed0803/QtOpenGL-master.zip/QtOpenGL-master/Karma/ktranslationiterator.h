#ifndef KTRANSLATIONITERATOR_H
#define KTRANSLATIONITERATOR_H KTranslationIterator

template <typename It, typename T>
class KTranslationIterator
{
public:
  typedef It IteratorType;
  typedef T ValueType;
};

#endif // KTRANSLATIONITERATOR_H
