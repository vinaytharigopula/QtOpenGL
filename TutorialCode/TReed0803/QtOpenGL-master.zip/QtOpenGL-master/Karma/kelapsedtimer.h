#ifndef KELAPSEDTIMER_H
#define KELAPSEDTIMER_H KElapsedTimer

#include <QElapsedTimer>

class KElapsedTimer : public QElapsedTimer
{
  // Intentionally Empty
};

#endif // KELAPSEDTIMER_H

