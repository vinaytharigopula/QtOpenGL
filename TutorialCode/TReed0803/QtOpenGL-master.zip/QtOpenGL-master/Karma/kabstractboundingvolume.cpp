#include "kabstractboundingvolume.h"

KAbstractBoundingVolume::KAbstractBoundingVolume()
{

}

KAbstractBoundingVolume::~KAbstractBoundingVolume()
{

}

