#ifndef KSTACK_H
#define KSTACK_H KStack

#include <QStack>

template <typename T>
class KStack : public QStack<T>
{
  // Intentionally Empty
};

#endif // KSTACK_H

