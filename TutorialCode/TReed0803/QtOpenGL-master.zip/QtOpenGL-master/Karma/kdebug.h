#ifndef KDEBUG_H
#define KDEBUG_H KDebug

#include <QDebug>
#define kDebug() qDebug()

#endif // KDEBUG_H

